package com.dn.mysql;

import java.sql.*;
public class Mysql {

	public Connection ct;

	public Mysql() {	//Mysql连接
		try {
			Class.forName("com.mysql.jdbc.Driver");
			ct = DriverManager.getConnection("jdbc:mysql://120.24.182.157:3306/test_class?useUnicode=true&autoReconnect=true&characterEncoding=utf-8", "tester", "dongnao110");
			DriverManager.setLoginTimeout(10);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
