package com.dn.mysql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

public class useMysql {
	private Connection ct;

	//初始化这个数据库连接对象
	public useMysql(Connection ct1) {
		ct = ct1;
	}

	public boolean Login(String name, String pwd) {
		String sql = "SELECT * FROM userinfo where username='" + name + "' AND pwd='" + pwd + "';";
		System.out.println(sql);
		// 保存结果�?
		ResultSet rs = null;
		// 创建执行sql的操作状�?
		Statement sm;
		try {
			sm = ct.createStatement();
			//执行查询
			rs = sm.executeQuery(sql);

			//执行更新，删除，插入操作
			//int rs1 = sm.executeUpdate(sql);
			
			if (rs != null && rs.next()){
				ResultSetMetaData rsmd = rs.getMetaData();
				HashMap<String, String> map = new HashMap<String,String>();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					map.put(rsmd.getColumnName(i),rs.getString(i));
				}
				System.out.println(map.toString());
				return true;
			}
			sm.close();
			rs.close();
		} catch (SQLException e) {
		}
		return false;
	}
	
	public boolean PLogin(String name, String pwd){
		//创建变量保存返回结果
		try {
			//创建调用存储过程的状�?
			CallableStatement cm=ct.prepareCall("{call login(?,?)}");
			//给存储过程添加参�?
			cm.setString(1, name);
			//cm.setInt(1, 1);
			cm.setString(2, pwd);
			//获取执行结果
			ResultSet rs=cm.executeQuery();
			//处理执行结果
			if (rs!=null && rs.next()) {
				ResultSetMetaData rsmd = rs.getMetaData();
				HashMap<String, String> map = new HashMap<String,String>();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					map.put(rsmd.getColumnName(i),rs.getString(i));
				}
				System.out.println(map.toString());
				return true;
			}
			cm.close();
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		return false;
	}
}







