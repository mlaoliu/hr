package com.dn.login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dn.mysql.Mysql;
import com.dn.mysql.useMysql;


/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public login() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 设置编码，避免汉字乱码
		// 返回值编码
		response.setContentType("text/html;charset=UTF-8");
		// 收到的参数编码
		request.setCharacterEncoding("UTF-8");
		// 获取请求参数
		String loginName = request.getParameter("loginName");
		String password = request.getParameter("pwd");
		System.out.println(loginName + "  " + password);
		// 定义返回字符串
		String result = "";
		// 设置当前登录的用户名在本地cookie中保存
//		Cookie nameCookie = new Cookie("loginName", loginName);
//		nameCookie.setMaxAge(1800);
//		response.addCookie(nameCookie);
		if ((loginName.length() > 5) && (password != null)) {
			// 校验当前用户是否有登录
			if (request.getSession().getAttribute("loginName") == null) {
				// 校验登录的用户名密码
				Mysql sql = new Mysql();
				useMysql run = new useMysql(sql.ct);
				if (run.PLogin(loginName, password)) {
					result = "{\"status\":0,\"msg\":\"恭喜您，登录成功!\"}";
					// 登录成功，则保存用户名信息
					request.getSession().setAttribute("loginName", loginName);
					//response.sendRedirect("static/KeyWords.html");
				} else {
					// 密码错误提示
					result = "{\"status\":401,\"msg\":\"用户名或者密码错误!\"}";
				}
			} else {
				// 重复登录提示
				// 如果登录的用户名和session中的一样，则是重复登录。
				if (request.getSession().getAttribute("loginName").equals(loginName))
					// 同一个用户重复登录
					result = "{\"status\":405,\"msg\":\"重复登录!\"}";
				// 多个用户登录提示
				else
					result = "{\"status\":405,\"msg\":\"重复登录!\"}";
				//response.sendRedirect("static/KeyWords.html");
			}
		} else {
			result = "{\"status\":404,\"msg\":\"参数错误!\"}";
		}
		// 返回服务器处理结果
		response.getWriter().append(result);
		// 打印客户端会话id
		// response.getWriter().append(request.getSession().getId());
	}
}
