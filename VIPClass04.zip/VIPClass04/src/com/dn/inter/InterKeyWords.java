package com.dn.inter;

import com.dn.common.ExcelWriter;

public class InterKeyWords {

	public sendUrl url;
	public jsonPase json;
	public ExcelWriter excelw;
	public int line=0;
	

	public InterKeyWords(ExcelWriter excel) {
		//初始化成员变量
		url = new sendUrl();
		json = new jsonPase();
		excelw = excel;
	}

	//设置保存请求cookie
	public void savecookie(){
		url.saveCookie();
	}
	
	//清除请求的cookie
	public void clearcookie(){
		url.clearCookie();
	}
	
	
	// post请求关键字
	public void post(String u, String param) {
		json.jsonList.clear();
		String str = url.sendPost(u, param);
		System.out.println(str);
		if(str==null || str.length()<=1){
			excelw.writeCell(line, 10, url.getExp());
		}else{
			excelw.writeCell(line, 10, str);
		}
		json.Pase(str, 0, false);
		System.out.println(json.jsonList);
	}

	// get请求关键字
	public void get(String u, String param) {
		json.jsonList.clear();
		String str = url.sendGet(u, param);
		System.out.println(str);
		excelw.writeCell(line, 10, str);
		json.Pase(str, 0, false);
	}
	
	//post请求关键字
	public void upload(String u,String param){
		json.jsonList.clear();
		String str = url.Upload(u, param);
		System.out.println(str);
		excelw.writeCell(line, 10, str);
		json.Pase(str, 0, false);
	}
	
	//校验相等
	public void equel(String key,String value,String index){
		//将字符串转为int类型
		int i=0;
		try {
			i=Integer.parseInt(index);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//处理倒序
		i = json.jsonList.size()-i;
		//校验结果相等
		try {
			System.out.println("json结果：" + json.jsonList.get(i).get(key));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		if(json.jsonList.size()>0 && json.jsonList!=null && json.jsonList.get(i).get(key)!=null && json.jsonList.get(i).get(key).equals(value)){
			System.out.println("Pass");
			excelw.writeCell(line, 9, "Pass");
		}else{
			System.out.println("Fail");
			excelw.writeCell(line, 9, "Fail");
		}
	}

}
