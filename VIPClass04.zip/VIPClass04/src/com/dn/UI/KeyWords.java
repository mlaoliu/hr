package com.dn.UI;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.dn.common.ExcelWriter;

public class KeyWords {
	private WebDriver driver;
	private String text;
	private ExcelWriter excel;
	public int line;

	public KeyWords(ExcelWriter e) {
		excel =e;
	}

	// 启动浏览器
	public void openBrowser(String b, String dpath) {
		switch (b) {
		case "cc":
			// 启动Chrome浏览器
			ChromeDriver cc = new ChromeDriver("", dpath+"/lib/chromedriver.exe");
			driver = cc.getdriver();
			break;
		case "ie":
			// 启动ie浏览器
			IEDriver ie = new IEDriver("", dpath);
			driver = ie.getdriver();
			break;
		case "ff":
			// 启动ff浏览器
			FFDriver ff = new FFDriver("", dpath);
			driver = ff.getdriver();
			break;
		default:
			// 默认启动Chrome浏览器
			ChromeDriver c = new ChromeDriver("", dpath);
			driver = c.getdriver();
		}
	}

	// 关闭浏览器
	public void closeBrowser() {
		try {
			driver.quit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 打开url地址
	public void getUrl(String url) {
		try {
			driver.get(url);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 等待时间
	public void sleep(String time) {
		int t = 1000;
		try {
			t = Integer.parseInt(time);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 固定等待2s
			Thread.sleep(t);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 点击元素
	public void click(String xpath) {
		try {
			driver.findElement(By.xpath(xpath)).click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 输入
	public void input(String xpath, String value) {
		try {
			driver.findElement(By.xpath(xpath)).clear();
			driver.findElement(By.xpath(xpath)).sendKeys(value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 关闭旧窗口，切换到新窗口操作
	public void closeOldWin() {
		List<String> handles = new ArrayList<String>();
		// 返回一个句柄集合
		Set<String> s = driver.getWindowHandles();
		// 循环获取集合里面的句柄，保存到List数组handles里面
		for (Iterator<String> it = s.iterator(); it.hasNext();) {
			handles.add(it.next().toString());
		}
		// 关闭第一个窗口
		driver.close();
		// 切换到新窗口
		try {
			driver.switchTo().window(handles.get(1));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 关闭新窗口
	public void closeNewWin() {
		List<String> handles = new ArrayList<String>();
		Set<String> s = driver.getWindowHandles();
		// 循环获取集合里面的句柄，保存到List数组handles里面
		for (Iterator<String> it = s.iterator(); it.hasNext();) {
			handles.add(it.next().toString());
		}
		driver.switchTo().window(handles.get(1));
		driver.close();
		driver.switchTo().window(handles.get(0));
	}

	// 进入iframe子页面
	public void intoIframe(String xpath) {
		try {
			driver.switchTo().frame(driver.findElement(By.xpath(xpath)));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("进入iframe失败！");
			e.printStackTrace();
		}
	}

	// 退出子页面
	public void outIframe() {
		driver.switchTo().defaultContent();
	}

	// 获取元素文本
	public String getText(String xpath) {
		String text = "null";
		try {
			text = driver.findElement(By.xpath(xpath)).getText();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return text;
	}

	// 鼠标悬停
	public void hover(String xpath) {
		Actions action = new Actions(driver);
		try {
			action.moveToElement(driver.findElement(By.xpath(xpath))).moveByOffset(10, 3).build().perform();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 运行js
	public void runJs(String text) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			js.executeScript(text);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 获取js运行结果
	public String getJs(String text) {
		String t = "";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			t = js.executeScript(text).toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return t;
	}

	// 实现select方法
	public void select(String xpath, String text) {
		try {
			Select userSelect = new Select(driver.findElement(By.xpath(xpath)));
			userSelect.selectByVisibleText(text);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 上传文件
	public void upload(String xpath, String file) {
		try {
			driver.findElement(By.xpath(xpath)).sendKeys(file);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 表单提交
	public void submit(String xpath) {
		try {
			driver.findElement(By.xpath(xpath)).submit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// 获取title
	public void getTitle() {
		try {
			text = driver.getTitle();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//校验text包含
	public void assertcontains(String value){
		if (text!=null && text.contains(value)){
			System.out.println("Pass");
			excel.writeCell(line, 4, "Pass");
		}else{
			System.out.println("Fail");
			excel.writeCell(line, 4, "Fail");
		}
	}
}
