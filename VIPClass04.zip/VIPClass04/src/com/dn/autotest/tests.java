package com.dn.autotest;

import com.dn.UI.KeyWords;

public class tests {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		KeyWords obj = new KeyWords();
		obj.openBrowser("cc", "D:\\Users\\Test\\chromedriver.exe");
		obj.getUrl("http://www.hsjcjwh.top/dn_biz/index.php");
		obj.runJs("document.body.scrollTop = 500;");
		obj.click("//*[@id=\"fl_f_0_pl\"]/ul/li[1]/div/a");
		obj.sleep("3000");
		obj.input("//*[@id=\"loginName\"]", "perlly");
		obj.input("//*[@id=\"loginPwd\"]", "dongnao");
		obj.input("//*[@id=\"verifyCode\"]", "1111");
		obj.submit("//*[@id=\"layui-layer1\"]/div[2]/form");
		obj.sleep("13000");
		obj.closeBrowser();
		
	}

}
