package com.dn.autotest;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.dn.UI.KeyWords;
import com.dn.common.ExcelReader;
import com.dn.common.ExcelWriter;
import com.dn.inter.InterKeyWords;

public class testinter {
	
	public static InterKeyWords inter;
	public static KeyWords ui;
	public static String filepath;
	
	public static void main(String[] args) throws IOException {
		String type = args[0];
		System.out.println(type);
//		String type = "1";
		//获取项目的绝对路径的
		File directory = new File("");
		filepath = directory.getCanonicalPath();
		System.out.println(filepath);
		String filename = "/lib/cases/";
		String fileres = "/lib/cases/result-";
		try {
			System.out.println("log::info：文件路径：" + filepath);
			switch (type) {
			case "1":
				filename += "UICases.xls";
				fileres += "UICases.xls";
				break;
			case "2":
				filename += "InterfaceCases.xls";
				fileres += "InterfaceCases.xls";
				break;
			case "3":
				filename += "APPCases.xls";
				fileres += "APPCases.xls";
				break;
			default:
				filename += "UICases.xls";
				fileres += "UICases.xls";
				System.out.println("log::error：类型错误！已经默认执行UI自动化。");
				break;
			}
			System.out.println("用例文件路径："+filepath + filename);
			GetCase(filepath + filename,filepath + fileres, type);// 设置用例文件的路径
		} catch (Exception e) {
			System.out.println("log::error：获取文件位置失败，请检查。");
			e.printStackTrace();
		}
		System.out.print("输入回车，退出...");
		try {
			System.in.read();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void GetCase(String file, String fileres, String type) {
		// 打开Excel
		ExcelReader excelr = new ExcelReader(file);
		ExcelWriter excelw = new ExcelWriter(file, fileres);
		List<String> line = null;
		inter = new InterKeyWords(excelw);
		ui = new KeyWords(excelw);
		//KeyWords ui = new KeyWords(excelw);

		excelr.useSheet(0);

		for (int i = 0; i < excelr.getRows(0); i++) {
			line = excelr.ReadLine(i);
			System.out.println(line);
			if (line.get(0).length() < 1) {
				switch (type) {
				case "1":
					ui.line = i;
					runUI(line, i);
					break;
				case "2":
					inter.line=i;
					runInter(line, i);
					break;
				case "3":
					break;
				default:
					;
				}
			}
		}
		excelr.close();
		excelw.close();
		
	}

	private static void runUI(List<String> list, int i) {
		try {
			switch(list.get(2)){
			case "openbrowser":
				ui.openBrowser(list.get(3), filepath);
				break;
			case "geturl":
				ui.getUrl(list.get(3));
				break;
			case "input":
				ui.input(list.get(3), list.get(4));
				break;
			case "click":
				ui.click(list.get(3));
				break;
			case "closeoldwindow":
				ui.closeOldWin();
				break;
			case "sleep":
				ui.sleep(list.get(3));
				break;
			case "gettitle":
				ui.getTitle();
				break;
			case "assertcontains":
				ui.assertcontains(list.get(3));
				break;
			case "closebrowser":
				ui.closeBrowser();
				break;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		
	}

	//执行接口用例
	private static void runInter(List<String> list, int i) {
		// TODO Auto-generated method stub
		//执行关键字相应操作
		try {
			switch(list.get(2)){
			case "post":
				inter.post(list.get(3), list.get(4));
				break;
			case "get":
				inter.get(list.get(3), list.get(4));
				break;
			case "savecookie":
				inter.savecookie();
				break;
			case "clearcookie":
				inter.clearcookie();
				break;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		try{
			switch(list.get(5)){
			case "equel":
				inter.equel(list.get(6), list.get(7),list.get(8));
				break;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}

}
