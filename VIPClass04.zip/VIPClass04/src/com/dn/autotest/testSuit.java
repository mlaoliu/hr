package com.dn.autotest;

import com.dn.UI.KeyWords;

public class testSuit {
	
	public static void main(String[] args) {
        //设置driver文件路径
		//System.setProperty("webdriver.chrome.driver", "D:\\Users\\Test\\chromedriver.exe");
		//打开相应浏览器
        //WebDriver driver = new ChromeDriver();
		KeyWords obj = new KeyWords();
		obj.openBrowser("cc", "D:\\Users\\Test\\chromedriver.exe");
		//登录
		obj.getUrl("http://120.24.182.157/dn_biz/index.php/home/users/regist.html");
		
		obj.input("//*[@id=\"loginName\"]", "VIP04_2");
		obj.input("//*[@id=\"loginPwd\"]", "dongnao");
		obj.input("//*[@id=\"reUserPwd\"]", "dongnao");
		obj.input("//*[@id=\"verifyCode\"]", "1111");
		obj.click("//*[@id=\"reg_form\"]/table/tbody/tr[6]/td/label[1]");
		obj.submit("//*[@id=\"reg_form\"]");
		
		obj.sleep("15000");
		obj.closeBrowser();
    }
	
	public static void main2(String[] args) {
        //设置driver文件路径
		//System.setProperty("webdriver.chrome.driver", "D:\\Users\\Test\\chromedriver.exe");
		//打开相应浏览器
        //WebDriver driver = new ChromeDriver();
		KeyWords obj = new KeyWords();
		obj.openBrowser("cc", "D:\\Users\\Test\\chromedriver.exe");
		//登录
		obj.getUrl("http://www.hsjcjwh.top/dn_biz/index.php/home/users/login.html");
		obj.input("//*[@id=\"loginName\"]", "perlly");
		obj.input("//*[@id=\"loginPwd\"]", "dongnao");
		obj.input("//*[@id=\"verifyCode\"]", "1111");
		obj.click("/html/body/div[5]/div/div[2]/form/table/tbody/tr[5]/td/div/a");
		obj.sleep("3000");
		obj.click("/html/body/div[1]/div/ul[2]/li[11]/div[1]");
		obj.closeOldWin();
		obj.sleep("2000");
		obj.click("/html/body/div[3]/div[3]/div[1]/ul[2]/li[2]");
		obj.sleep("2000");
		System.out.println(
				obj.getJs("return document.getElementsByClassName(\"wst-menua wst-menuas\")[0].innerText;"));
		obj.input("//*[@id=\"goodsName\"]", "测试商品");
		obj.input("//*[@id=\"marketPrice\"]", "100.00");
		obj.input("//*[@id=\"shopPrice\"]", "99.90");
		obj.input("//*[@id=\"goodsStock\"]", "100");
		obj.input("//*[@id=\"warnStock\"]", "10");
		obj.input("//*[@id=\"goodsUnit\"]", "动脑学院");
		obj.input("//*[@id=\"goodsSeoKeywords\"]", "测试");
		obj.runJs("document.getElementById(\"goodsTips\").value = \"测试商品\";");
		//obj.input("//*[@id=\"goodsTips\"]", "测试的东西");
		obj.click("//*[@id=\"editform\"]/div[1]/table/tbody/tr[12]/td/div/label[2]");
		obj.click("//*[@id=\"cat_0\"]");
		obj.click("//*[@id=\"cat_0\"]/option[3]");
//		obj.click("//*[@id=\"shopCatId1\"]");
//		obj.click("//*[@id=\"shopCatId1\"]/option[3]");
//		obj.click("//*[@id=\"shopCatId2\"]");
//		obj.click("//*[@id=\"shopCatId2\"]/option[3]");
		obj.select("//*[@id=\"shopCatId1\"]", "食品饮料");
		obj.sleep("500");
		obj.select("//*[@id=\"shopCatId2\"]", "糖果饼干");

		//上传文件
		obj.input("//*[@id=\"goodsImgPicker\"]/div[2]/input", "C:\\Users\\perlly\\Desktop\\apptest\\test.png");
		obj.sleep("2000");
		
		obj.intoIframe("//*[@id=\"editform\"]/div[1]/table/tbody/tr[16]/td/div/div[2]/iframe");
		obj.input("/html/body", "测试一下");
		
		obj.outIframe();
		obj.click("//*[@id=\"editform\"]/div[1]/table/tbody/tr[17]/td/button[1]");
		
		obj.sleep("15000");
		obj.closeBrowser();
    }

	public static void main1(String[] args) {
        //设置driver文件路径
		//System.setProperty("webdriver.chrome.driver", "D:\\Users\\Test\\chromedriver.exe");
		//打开相应浏览器
        //WebDriver driver = new ChromeDriver();
		KeyWords obj = new KeyWords();
		obj.openBrowser("cc", "D:\\Users\\Test\\chromedriver.exe");
		obj.getUrl("https://ke.qq.com/course/168816#tuin=45266413");
		obj.click("//*[@id=\"js-tips-close\"]");
		obj.runJs("document.body.scrollTop = 500");
		obj.sleep("1000");
		obj.click("/html/body/section[2]/div/div[2]/div[2]/div/a[1]");
		obj.closeOldWin();
		obj.sleep("2000");
		obj.click("//*[@id=\"js-section-main\"]/div/aside/div[1]/div/a");
		obj.sleep("2000");
		obj.closeOldWin();
		obj.click("//*[@id=\"js_login\"]");
		obj.sleep("1000");
		obj.click("/html/body/div[3]/div/div[2]/div[2]/a[1]");
		obj.intoIframe("/html/body/div[3]/div/div[1]/div[2]/iframe");
		obj.click("//*[@id=\"qlogin_list\"]/a[1]");
		obj.sleep("3000");
		//校验是否登录成功
		System.out.println(obj.getText("//*[@id=\"js_logout_outer\"]/p/a"));
		
		obj.hover("//*[@id=\"js_btn_bar\"]/span[3]/span[1]");
		obj.click("//*[@id=\"js_btn_bar\"]/span[3]/span[2]");
		obj.sleep("1000");
		System.out.println(obj.getText("/html/body/div[3]/div[2]/div/p"));
		obj.click("/html/body/div[3]/div[1]/a");
		
		obj.sleep("13000");
		obj.closeBrowser();
    }

}
