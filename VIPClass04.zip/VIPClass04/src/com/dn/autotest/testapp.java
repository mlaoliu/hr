package com.dn.autotest;

import org.openqa.selenium.By;

import com.dn.app.KeyWordsAPP;
import com.dn.app.appDriver;
import io.appium.java_client.android.AndroidDriver;

public class testapp {

	
public static void main(String[] args) {
	
	KeyWordsAPP app = new KeyWordsAPP();
	app.swipe(700,225,700,1225,1000);
	app.runAppium("353ACHRUFWTN", "com.tencent.mobileqq",5000);
	app.runAPP("353ACHRUFWTN", ".activity.SplashActivity", 5000);
	app.input("//android.widget.EditText[@text='1052949192' and @content-desc='请输入QQ号码或手机或邮箱']", "1052949192");
	app.input("//android.widget.EditText[@resource-id='com.tencent.mobileqq:id/password']", "wuqingfqng");
	app.click("//android.widget.Button[@resource-id='com.tencent.mobileqq:id/login']");
//	//点击联系人
//	app.click("//android.widget.TabWidget[@resource-id='android:id/tabs']/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.view.View[1]");
//	//搜索
//	app.input("//android.widget.EditText[@resource-id='com.tencent.mobileqq:id/et_search_keyword']", "倩倩");
//	//点击搜到的第一个人
//	app.click("//android.widget.AbsListView[@resource-id='com.tencent.mobileqq:id/name']/android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]");
//	//点击头像
//	app.click("//android.widget.ImageView[@resource-id='com.tencent.mobileqq:id/ivTitleBtnRightImage']");
//	//点击人
//	app.click("//android.widget.LinearLayout[@resource-id='com.tencent.mobileqq:id/name']/android.widget.RelativeLayout[1]");
//	//点击空间
//	app.wait(2000);
//	app.click("//android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.RelativeLayout[1]/android.widget.AbsListView[1]/android.widget.LinearLayout[2]/android.widget.LinearLayout[1]/android.widget.LinearLayout[4]");
//	//点击日志
//	app.wait(3000);
//	app.click("//android.widget.LinearLayout/android.widget.FrameLayout[2]/android.widget.LinearLayout[1]");
//	
	app.wait(10000);
	app.quit();
	}
	
	public static void main1(String[] args) {
		
		appDriver app = new appDriver("127.0.0.1:52001",".activity.SplashActivity","http://127.0.0.1:4723/wd/hub",10000);
		AndroidDriver driver = app.getdriver();
		driver.findElement(By.xpath("//android.widget.EditText[@text='1052949192' and @content-desc='请输入QQ号码或手机或邮箱']")).sendKeys("1052949192");
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='com.tencent.mobileqq:id/password']")).sendKeys("wuqingfqng");
		driver.findElement(By.xpath("//android.widget.Button[@resource-id='com.tencent.mobileqq:id/login']")).click();
		
//		runAppCase appr = new runAppCase();
//		appr.runAppium("Android", "127.0.0.1:52001", "com.tencent.mobileqq");
//		appr.wait(10000);
//		appr.runApp("127.0.0.1:52001", "com.tencent.mobileqq.activity.SplashActivity", "15000");
	}
}
