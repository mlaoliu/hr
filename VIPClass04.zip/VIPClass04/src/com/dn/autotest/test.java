package com.dn.autotest;
import com.dn.app.KeyWordsAPP;
import com.dn.common.ExcelReader;
import com.dn.inter.jsonPase;
import com.dn.inter.sendUrl;

public class test {

	public static void main(String[] args) {

//		//打开Excel
		ExcelReader excelr = new ExcelReader("C:\\Users\\perlly\\Desktop\\apptest\\VIP04\\Cases\\login.xls");
//		//选择sheet页
//		excelr.useSheet(0);
//		//读取一行
//		System.out.println(excelr.ReadLine(0));
//		//读取一行的某一个单元格
//		System.out.println(excelr.ReadLine(0).get(0));
//		//操作完成，关闭
//		excelr.close();
		sendUrl url = new sendUrl();
		url.saveCookie();
		String str = url.sendPost("http://localhost:8081/Class2/login", "loginName=dongnao01&pwd=dongnao");
		System.out.println(str);
		str = url.sendPost("http://localhost:8081/Class2/login", "loginName=dongnao01&pwd=dongnao");
		System.out.println(str);
		url.clearCookie();
		str = url.sendPost("http://localhost:8081/Class2/login", "loginName=dongnao01&pwd=dongnao");
		System.out.println(str);
		str = url.sendPost("http://localhost:8081/Class2/login", "loginName=dongnao01&pwd=dongnao");
		System.out.println(str);
	}
	
	public static void main1(String[] args) {
		// appDriver app = new appDriver("0123456789ABCDEF",
		// "com.tencent.mobileqq.activity.SplashActivity","http://127.0.0.1:4444/wd/hub",
		// "10000");
		// AndroidDriver driver = app.getdriver();

		KeyWordsAPP appr = new KeyWordsAPP();
		appr.runAppium("353ACHRUFWTN", "com.android.browser",5000);
		appr.runAPP("353ACHRUFWTN", "com.android.browser.BrowserActivity", 5000);
		// appr.driver = driver;
		appr.wait(3000);

		appr.getUrl("https://h5.qzone.qq.com/ugc/share?_wv=1&appid=2&res_uin=873403874&cellid=1462955970");
		//appr.click("//*[@id=\"guideSkip\"]");
		appr.wait(2000);
		appr.input("//*[@id=\"u\"]", "1052949192");
		appr.input("//*[@id=\"p\"]", "wuqingfqng");
		appr.click("//*[@id=\"go\"]");
		appr.wait(20000);
		appr.quit();
	}
}