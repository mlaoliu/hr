package com.dn.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;

import org.openqa.selenium.By;

import io.appium.java_client.android.AndroidDriver;

public class KeyWordsAPP {

	// 用来保存操作APP的driver对象
	public AndroidDriver driver;

	public KeyWordsAPP() {
		// runCmd("cmd /c start ");
	}

	// 执行adb命令
	public void runAdb(String c) {
		String cmd = "cmd /c start " + c;
		runCmd(cmd);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 按键
	public void pressKey(int k) {
		String cmd = "cmd /c start adb shell input keyevent " + k;
		runCmd(cmd);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void wait(int t) {
		try {
			Thread.sleep(t);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 通过路径，启动模拟器，并等待启动完成
	public void runAVD(String avd, int t) {
		runCmd(avd);
		try {
			Thread.sleep(t);
			// System.out.println("1");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 启动appium服务
	public void runAppium(String device, String apppkg, int time) {
		if (!isPortUsing(4723)) {
			String cmd = "appium -a 127.0.0.1 -p 4723 --platform-name Android --platform-version 18 --device-name "
					+ device + " --app-pkg " + apppkg + " --automation-name Appium --log-no-color";
			runCmd(cmd);
			this.wait(time);
		} else {
			System.out.println("log::error：Appium 端口4723以被占用，请检查服务是否已经启动");
		}
		return;
	}

	// 启动被测APP
	public void runAPP(String deviceName, String appActivity, int time) {
		appDriver app = new appDriver(deviceName, appActivity, "http://127.0.0.1:4723/wd/hub", time);
		this.wait(time);
		driver = app.getdriver();
	}

	// 脚本执行CMD命令的函数
	public void runCmd(String str) {
		String cmd = "cmd /c start " + str;
		Runtime runtime = Runtime.getRuntime();
		try {
			runtime.exec(cmd);
		} catch (Exception e) {
			System.out.println("log::error：执行cmd命令错误!");
		}
		return;
	}

	// 查看端口是否被占用
	public static boolean isPortUsing(int port) {
		boolean flag = false;
		// 如果端口没有被占用，就返回false，反之，返回true
		try {
			InetAddress theAddress = InetAddress.getByName("127.0.0.1");
			Socket socket = new Socket(theAddress, port);
			flag = true;
			socket.close();
		} catch (IOException e) {

		}
		return flag;
	}
	
	public void click(String xpath){
		this.wait(1000);
		driver.findElement(By.xpath(xpath)).click();
	}
	
	public void input(String xpath,String value){
		this.wait(1000);
		driver.findElement(By.xpath(xpath)).sendKeys(value);
	}

	public void quit() {
		// TODO Auto-generated method stub
		try {
			driver.quit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void swipe(int i, int j, int k, int l, int m) {
		this.runCmd("adb shell input swipe " + i + " " + j + " " + k + " " + l +" " + m );		
	}

	public void getUrl(String url){
		try {
			driver.get(url);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("log::error：网址打开失败！");
			e.printStackTrace();
		}
	}
	
}
